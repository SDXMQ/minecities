package com.minecolonies.api.colony.requestsystem.requestable.deliveryman;

import com.google.common.reflect.TypeToken;
import com.minecolonies.api.colony.requestsystem.factory.IFactoryController;
import com.minecolonies.api.util.ReflectionUtils;
import com.minecolonies.api.util.constant.TypeConstants;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * Class used to represent pickups inside the request system. This class can be used to request a pickup of
 */
public class Pickup extends AbstractDeliverymanRequestable
{
    /**
     * Set of type tokens belonging to this class.
     */
    private final static Set<TypeToken<?>>
      TYPE_TOKENS = ReflectionUtils.getSuperClasses(TypeToken.of(Pickup.class)).stream().filter(type -> !type.equals(TypeConstants.OBJECT)).collect(Collectors.toSet());

    /**
     * Day by which the pickup should be done (unless courier is idle).
     */
    private int day;

    /**
     * Qty of items to be picked up (estimate).
     */
    private int quantity;

    /**
     * Constructor for Delivery requests
     *
     * @param priority The priority of the request.
     */
    public Pickup(final int priority, final int day, final int qty)
    {
        super(priority);
        this.day = day;
        this.quantity = qty;
    }

    @NotNull
    public static CompoundTag serialize(@NotNull final IFactoryController controller, final Pickup pickup)
    {
        final CompoundTag compound = new CompoundTag();
        compound.put(NBT_PRIORITY, controller.serialize(pickup.getPriority()));
        compound.put(NBT_DAY, controller.serialize(pickup.getDay()));
        compound.put(NBT_QTY, controller.serialize(pickup.getQuantity()));

        return compound;
    }

    /**
     * Get the pickup day.
     * @return the day.
     */
    public int getDay()
    {
        return day;
    }

    /**
     * Get the pickup quantity.
     * @return the qty.
     */
    public int getQuantity()
    {
        return quantity;
    }

    /**
     * Setter for the day.
     * @param day the new day.
     */
    public void setDay(final int day)
    {
        this.day = day;
    }

    /**
     * Setter for the qty.
     * @param qty the new qty.
     */
    public void setQuantity(final int qty)
    {
        this.quantity = qty;
    }

    @NotNull
    public static Pickup deserialize(@NotNull final IFactoryController controller, @NotNull final CompoundTag compound)
    {
        final int priority = controller.deserialize(compound.getCompound(NBT_PRIORITY));
        final int day;
        if (compound.contains(NBT_DAY))
        {
            day = controller.deserialize(compound.getCompound(NBT_DAY));
        }
        else
        {
            day = -1;
        }

        final int qty;
        if (compound.contains(NBT_QTY))
        {
            qty = controller.deserialize(compound.getCompound(NBT_QTY));
        }
        else
        {
            qty = -1;
        }

        return new Pickup(priority, day, qty);
    }

    /**
     * Serialize the deliverable.
     *
     * @param controller the controller.
     * @param buffer     the the buffer to write to.
     * @param input      the input to serialize.
     */
    public static void serialize(final IFactoryController controller, final FriendlyByteBuf buffer, final Pickup input)
    {
        buffer.writeInt(input.getPriority());
        buffer.writeInt(input.getDay());
        buffer.writeInt(input.getQuantity());
    }

    /**
     * Deserialize the deliverable.
     *
     * @param controller the controller.
     * @param buffer     the buffer to read.
     * @return the deliverable.
     */
    public static Pickup deserialize(final IFactoryController controller, final FriendlyByteBuf buffer)
    {
        final int priority = buffer.readInt();
        final int day = buffer.readInt();
        final int qty = buffer.readInt();

        return new Pickup(priority, day, qty);
    }

    @Override
    public boolean equals(final Object o)
    {
        // Note that the super class will compare the priority.
        if (!super.equals(o))
        {
            return false;
        }
        if (this == o)
        {
            return true;
        }
        return o instanceof Pickup;
    }

    @Override
    public String toString()
    {
        return "Pickup{" +
                 "priority=" + priority +
                 '}';
    }

    @Override
    public Set<TypeToken<?>> getSuperClasses()
    {
        return TYPE_TOKENS;
    }
}
